
## 08:59 | main
Created THEOLOGICUS-v1.0.8-Setup.zip using 7-Zip and added to git for Windows installer distribution.