"""Ajoute xerj_url et xerj_memory_namespace à config/api_keys.json."""
import json
from pathlib import Path

cfg_path = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
changed = False
if "xerj_url" not in cfg:
    cfg["xerj_url"] = "http://localhost:9200"
    changed = True
if "xerj_memory_namespace" not in cfg:
    cfg["xerj_memory_namespace"] = "markliv"
    changed = True
if changed:
    cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
print("config xerj:", "ok" if changed else "déjà présent")
