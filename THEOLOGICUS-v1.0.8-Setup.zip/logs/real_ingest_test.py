"""TEST RÉEL (autorisé par l'utilisateur) : ingestion réelle d'un document
réel par 2 agents réels (Gemini réel) dans le VRAI vault, puis QA appuyée
sur les pages écrites, puis vérification de dérive."""
import importlib.util
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
for stream in ("stdout", "stderr"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = Path(__file__).resolve().parent.parent
fp = load("fp_real", base / "actions" / "file_processor.py")
agents_mod = load("agents_real", base / "actions" / "theology_agents.py")
sc = load("sc_real", base / "actions" / "theology_self_check.py")

src = Path(t := base).parent / "Documents" / "Theology"  # unused placeholder
src = Path.home() / "Documents" / "Theology" / "raw" / "6-9_Probleme d abrogation_.docx"
assert src.exists(), src

profiles = [p for p in agents_mod.discover_agents()
            if p.name in ("Apologete Catholique", "Exegese")]
assert len(profiles) == 2, [p.name for p in profiles]

report = fp._run_ingest(
    [src], "learn", "", {}, None, None, None,
    learn_profiles=profiles)
print("\n=== INGESTION RÉELLE ===")
print(report)

# ── Questions sur le document, comme l'utilisateur les poserait à MARK-LIV ──
bridge = fp._theology_brain_module()
hits = bridge.run({"action": "search", "query": "abrogation nasikh mansukh"})
print("\n=== SEARCH (local, hors-ligne) ===")
print(hits[:900])

qa_prompt = (
    "Tu es MARK-LIV. Réponds en français, UNIQUEMENT à partir des extraits du "
    "vault ci-dessous (pas d'apport externe), en citant les pages [[...]].\n"
    "QUESTION : D'après le document '6-9_Probleme d abrogation', qu'est-ce que "
    "l'abrogation (nasikh/mansukh) et quel(s) problème(s) pose-t-elle ?\n\n"
    "EXTRAITS DU VAULT :\n" + hits[:4000] + "\n\nRÉPONSE :"
)
answer = fp._gemini_client().generate_content(qa_prompt)
print("\n=== RÉPONSE DE MARK-LIV (appuyée sur le vault) ===")
print((answer.text or "").strip()[:1200])

print("\n=== VÉRIFICATION DE DÉRIVE (refresh + check) ===")
print(sc.theology_self_check({"action": "refresh"}, player=None))
