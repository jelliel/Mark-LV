"""Ajoute theology_agents_dir à config/api_keys.json (sans toucher au reste)."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
cfg_path = root / "config" / "api_keys.json"
cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
if "theology_agents_dir" not in cfg:
    cfg["theology_agents_dir"] = str(Path.home() / "Desktop" / "Agents")
    cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    print("added theology_agents_dir")
else:
    print("already present:", cfg["theology_agents_dir"])
