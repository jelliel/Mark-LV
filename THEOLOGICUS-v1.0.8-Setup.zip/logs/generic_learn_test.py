"""Test du chemin générique _theology_learn (sans agents) : vault temporaire,
Gemini simulé, doc self-knowledge + miroir de prompt vérifiés."""
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
for stream in ("stdout", "stderr"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = Path(__file__).resolve().parent.parent / "actions"
fp = load("fp_gen_test", base / "file_processor.py")
tb = load("tb_gen_test", base / "theology_brain.py")
ta = load("ta_gen_test", base / "theology_agents.py")

tmp = Path(tempfile.mkdtemp(prefix="markliv_gen_"))
app_root = tmp / "appdir"
tb._vault = lambda: tmp
tb._base_dir = lambda: app_root


class _FakeResponse:
    def __init__(self):
        self.text = ('{"source": {"title": "Gen Source", "tags": "test", '
                     '"body": "Resume."}, '
                     '"entities": [{"title": "Gen Entity", "tags": "t", "body": "E."}], '
                     '"concepts": [{"title": "Gen Concept", "tags": "t", "body": "C."}]}')


class _FakeGemini:
    def generate_content(self, prompt):
        # La source doit voir l'etat du brain injecte (self-improvement generique).
        assert "ALREADY IN THE VAULT" in prompt, "vault context absent du prompt"
        return _FakeResponse()


fp._gemini_client = lambda: _FakeGemini()
ta._load_file_processor = lambda: fp
fp._theology_brain_module = lambda: tb

src = tmp / "doc.txt"
src.write_text("A general grace text for the generic path.", encoding="utf-8")

result = fp._theology_learn([src], {}, player=None, step=None, profiles=None)
print("RESULT:", result)

assert "3 page(s)" in result, result
assert "Self-knowledge mise à jour" in result, result
self_doc = tmp / "self" / "mark-liv-theology.md"
assert self_doc.exists(), "doc self-knowledge absent"
sd = self_doc.read_text(encoding="utf-8")
for marker in ("AUTO-START: status", "AUTO-START: agents", "AUTO-START: recent"):
    assert marker in sd, marker
assert "Gen Source" in (app_root / "memory" / "long_term.json").read_text(encoding="utf-8")
# Deuxieme passe : le vault context doit maintenant lister ce qui existe.
captured = {}
class _G2(_FakeGemini):
    def generate_content(self, prompt):
        captured["p"] = prompt
        return _FakeResponse()
fp._gemini_client = lambda: _G2()
result2 = fp._theology_learn([src], {}, profiles=None)
assert "Gen Entity" in captured["p"], "le 2e passage ne voit pas le 1er etat du brain"
backup = Path(str(tmp) + "_keep")
# second passage ok
print("GENERIC LEARN OK - self-improvement verifie sur 2 passes")

shutil.rmtree(tmp)
