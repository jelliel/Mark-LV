# MARK-LIV Theology — Self-Knowledge of the Team

_Identity section written by hand. The AUTO blocks are regenerated after each
ingestion — never edited by hand. (Pattern: a living "self-knowledge" doc,
AUTO blocks marked by HTML comments, refreshed metadata never touching the
hand-written sections.)_

## Identity

MARK-LIV compiles the sources ingested by the user into a linked theology
vault (sources, entities, concepts). A team of specialist agents reads each
source through its own specialty and writes attributed pages. This document
is the team's shared self-image: what the brain knows, who wrote what,
and what it just learned.


<!-- AUTO-START: status -->
## Vault schema — 3 page(s), 1 raw source(s)

- sources: 1
- entities: 1
- concepts: 1
- synthesis: 0

<!-- AUTO-END: status -->

<!-- AUTO-START: agents -->
## Agents of the team

- **Apologete Catholique** — Apologete Catholique > Tu es un Théologien-Débattant Catholique de premier plan, spécialiste en apologétique catholique 

<!-- AUTO-END: agents -->

<!-- AUTO-START: contributions -->
## Pages written per agent

- Apologete Catholique: 3 page(s) tagged

<!-- AUTO-END: contributions -->

<!-- AUTO-START: recent -->
## Latest learning

- Apologete Catholique → ui_smoke_input.txt (3 page(s))

<!-- AUTO-END: recent -->

## Deeper

- Full index: `wiki/index.md` — chronological operations: `wiki/log.md`.
- User project state (hand-written, yours): `MEMORY.md`.
