# Theology — Project State

_Curated by MARK-LIV. Edit freely; this file is yours._

## Current focus

_(nothing recorded yet — ask MARK-LIV to run a summary after your next session)_
