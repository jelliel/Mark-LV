---
title: Source UI
kind: source
tags: [test, Apologete Catholique]
sources: [ui_smoke_input.txt — Apologete Catholique]
created: 2026-10-17
updated: 2026-10-17
---

Agent: Apologete Catholique

Resume.
