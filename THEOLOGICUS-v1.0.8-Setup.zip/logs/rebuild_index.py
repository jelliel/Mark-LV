"""Rebuild the real vault index and note the smoke-test cleanup in the log."""
import importlib.util
from pathlib import Path

root = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location(
    "tb_clean", root / "actions" / "theology_brain.py")
tb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tb)
print(tb.run({"action": "init"}))
note = ("## [2026-10-16] cleanup - 6 pages + note.txt d'un test supprimees "
        "(Agent: Apologete, sources: note.txt)\n")
with open(tb._vault() / "wiki" / "log.md", "a", encoding="utf-8") as f:
    f.write(note)
print("log noted")
