"""Test UI hors écran : la barre de références affiche TOUTES les [[refs]],
et un clic résout la page réelle du vault (lecture seule)."""
import importlib.util
import os
import sys
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
for stream in ("stdout", "stderr"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Charge ui.py réel (gros fichier : import complet, aucune fenêtre ouverte).
spec = importlib.util.spec_from_file_location("markliv_ui", "ui.py")
ui = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ui)

from PyQt6.QtWidgets import QApplication
app = QApplication([])

# ── SANS références : la barre reste cachée.
bar = ui._RefsBar()
assert not bar.isVisible() and bar.set_refs([]) == 0

# ── Avec 26 références (doublons inclus) : TOUTES affichées, dédupliquées.
text = " ".join(f"[[Ref {i}]]" for i in range(26)) + " [[Ref 3]]"
n = bar.set_refs(ui._REFS_RE.findall(text))
assert n == 26, n
assert bar.isVisible()
html = bar._label.text()
for i in range(26):
    assert f"ref:Ref {i}" in html, i
# Taux d'affichage : 26 sur 26, aucune troncature.
print(f"({n} puces affichées — aucune omise)")

# ── Résolution réelle : une vraie page du vault s'ouvre complètement.
found = ui._vault_page("Abrogation et Coran")
assert found is not None, "page réelle non résolue"
title, kind, body = found
print(f"page réelle: [{kind}] {title} — {len(body)} caractères")
assert body and len(body) > 40, body[:80]
assert "abrogation" in body.lower(), body[:120]

page = ui._RefPage(title, kind, body)
assert page.windowTitle().startswith(title)

# ── Référence morte : pas de crash, message honnête (le corps nomme la page).
missing = ui._RefMissing("Page Fantôme X")
assert missing.windowTitle() == "Référence introuvable"

# ── Bouton « Tout ouvrir » : caché à 1 ref, affiché avec le compte à 2+.
bar.set_refs(["Abrogation et Coran"])
assert not bar._all_btn.isVisible(), "le bouton ne doit pas s'afficher pour 1 seule ref"
n = bar.set_refs(["Abrogation et Coran", "Ref A", "Ref B", "Ref C"])
assert n == 4 and bar._all_btn.isVisible()
assert "4" in bar._all_btn.text(), bar._all_btn.text()
print("bouton « Tout ouvrir » : visible dès 2 refs, compte dans le libellé")

# ── Visionneuse empilée : pages réelles préchargées en un seul chargement.
import importlib.util as _ilu
_tspec = _ilu.spec_from_file_location("tb_titles", "actions/theology_brain.py")
_tb = _ilu.module_from_spec(_tspec); _tspec.loader.exec_module(_tb)
real_titles = []
for dirname, p in _tb._iter_pages(_tb._vault()):
    meta, _b = _tb._read_page(p)
    real_titles.append(_tb._page_title(p, meta))

batch = list(dict.fromkeys(real_titles))[:30]   # dédoublonné comme la barre
batch.append("Page Fantôme X")                  # 20+ exigés : au moins 30
loaded = ui._load_refs_bulk(batch)
assert len(loaded) == len(batch)
assert loaded[-1][2] is None, "le fantôme doit rester introuvable"
resolved_bodies = [b for (_t, _k, b) in loaded if b]
print(f"bulk load : {len(resolved_bodies)}/{len(batch)} pages résolues en un seul chargement")
assert len(resolved_bodies) >= 30, "préchargement du batch trop faible"

viewer = ui._RefsStacked(batch)
assert viewer._stack.count() == len(batch), viewer._stack.count()
assert viewer._list.count() == len(batch)
fant_row = len(batch) - 1
assert viewer._list.item(fant_row).text().startswith("⚠"), "fantôme non marqué"
assert "page absente" in viewer._stack.widget(fant_row).toPlainText()
first_pane = viewer._stack.widget(0).toPlainText()
assert first_pane and first_pane != "(page absente du vault — renommée ou supprimée)", first_pane[:60]
assert "introuvable" in viewer.windowTitle()
print(f"visionneuse empilée : {viewer._stack.count()} onglets, fantôme marqué, contenu réel en tête")

# ── Recherche Ctrl+F : comptage sur TOUTES les pages, navigation, surlignage.
pane0 = viewer._stack.widget(0)
assert pane0.toPlainText(), "pane vide"
viewer._search.setText("abrogation")          # déclenche _apply_search
info = viewer._match_info.text()
assert "correspondance" in info, info
assert "0 correspondance" not in info, info
assert "page(s)" in info, info
page_i = viewer._stack.currentIndex()
# La sélection a sauté sur la 1re page contenant un match...
cursor = viewer._pages[page_i].textCursor()
assert cursor.hasSelection() and cursor.selectedText().lower() == "abrogation", \
    repr(cursor.selectedText())
# ...ET toutes les occurrences de cette page sont surlignées.
assert len(viewer._pages[page_i].extraSelections()) > 0, "surlignage absent"
print(f"recherche : {info} | sélection+surlignage OK (onglet {page_i + 1})")

# ── Correspondances par page : le panneau gauche porte les comptes.
ann = [viewer._items[i].text() for i in range(len(batch))]
from PyQt6.QtGui import QColor
hits_annot = [i for i, t in enumerate(ann) if t.rstrip().endswith(")") and not t.startswith("⚠ ")]
assert len(hits_annot) == 7, hits_annot
hit_total = sum(int(ann[i].rsplit("(", 1)[1].rstrip(")")) for i in hits_annot)
assert hit_total == 13, (hit_total, ann)
for i in hits_annot:
    assert viewer._items[i].text().startswith("["), (i, viewer._items[i].text())
    assert viewer._items[i].foreground().color().name() == QColor("#ffcc00").name(), i
miss_annot = [i for i in range(len(batch)) if i not in hits_annot]
for i in miss_annot:
    assert viewer._items[i].foreground().color().name() == QColor("#3a8a9a").name(), i
    assert viewer._items[i].text() == viewer._base_items[i], i
print(f"correspondances par page : {len(hits_annot)} onglets chiffrés (total {hit_total}), "
      f"{len(miss_annot)} grisés, libellés de base intacts")

# Navigation : › avance dans la page puis saute aux pages suivantes sans blocage.
seen_panes = set()
for _ in range(40):                              # assez pour boucler plusieurs pages
    viewer._next_match()
    seen_panes.add(viewer._stack.currentIndex())
    assert viewer._match_info.text(), viewer._match_info.text()
assert len(seen_panes) > 1, "la navigation ne traverse pas plusieurs pages"
# ‹ revient en arrière
viewer._prev_match()
assert viewer._stack.currentIndex() in seen_panes
print(f"navigation ‹/› : {len(seen_panes)} onglets traversés, pas de blocage")

# Terme absent : 0 correspondance, pas de sélection parasite.
viewer._search.setText("xyzintrouvable999")
assert viewer._match_info.text() == "0 correspondance", repr(viewer._match_info.text())
# Vidage : reset propre.
viewer._search.setText("")
assert viewer._match_info.text() == "", repr(viewer._match_info.text())
# Restauration : libellés de base + couleur standard sur TOUT le panneau.
for i, item in enumerate(viewer._items):
    assert item.text() == viewer._base_items[i], (i, item.text())
    assert item.foreground().color().name() == QColor("#8ffcff").name(), i
print("restauration du panneau gauche après vidage : libellés et couleurs d'origine")
assert not viewer._pages[viewer._stack.currentIndex()].textCursor().hasSelection()
assert viewer._pages[0].extraSelections() == []
print("recherche : 0-match et reset propres")

print("REFS BAR OK — toutes les références affichées, toutes ouvrables, cherchables")
