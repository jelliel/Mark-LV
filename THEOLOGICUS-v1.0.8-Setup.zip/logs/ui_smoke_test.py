"""UI smoke test (offscreen) : la fenêtre d'ingestion et son sélecteur d'agents."""
import importlib.util
import os
import sys
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"
for stream in ("stdout", "stderr"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, root / rel)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


fp = load("fp_ui_test", "actions/file_processor.py")

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QApplication, QDialog

app = QApplication([])

calls = []

# ── Chaîne RÉELLE : _run_ingest → learn_with_agents, avec un vault temporaire
# et un Gemini simulé, pour que le contrat step(report) soit vérifié tel que
# l'app l'exécute (le bug 'int vs str' venait d'un décalage de signature).
def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, root / rel)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ta = load("ta_ui_test", "actions/theology_agents.py")
tb = load("tb_ui_test", "actions/theology_brain.py")

tmp_vault = root / "logs" / "ui_smoke_vault"
import shutil
if tmp_vault.exists():
    shutil.rmtree(tmp_vault)
tmp_vault.mkdir()
tb._vault = lambda: tmp_vault
tb._base_dir = lambda: tmp_vault / "appdir"   # miroir long_term.json isolé


class _FakeResponse:
    def __init__(self):
        self.text = ('{"source": {"title": "Source UI", "tags": "test", '
                     '"body": "Resume."}, '
                     '"entities": [{"title": "E1", "tags": "t", "body": "E page."}], '
                     '"concepts": [{"title": "C1", "tags": "t", "body": "C page."}]}'
                     )


class _FakeGemini:
    def generate_content(self, prompt):
        assert "Apologete" in prompt
        return _FakeResponse()


fp._gemini_client = lambda: _FakeGemini()
ta._load_file_processor = lambda: fp
fp._theology_brain_module = lambda: tb

# La chaîne réelle recharge theology_agents par nom fixe : on la redirige
# vers l'instance ta ci-dessus (faux Gemini + vault temporaire garantis).
fp._load_theology_agents = lambda: ta

# reports capturés pour valider (done, total) bien INT à travers toute la chaîne
reports = []
real_run_ingest = fp._run_ingest


def capturing_run_ingest(paths, mode, action, params, speak, player, report=None,
                         learn_profiles=None):
    def guard(done, total, label):
        assert isinstance(done, int) and isinstance(total, int), \
            (type(done), type(total), repr(label)[:80])
        reports.append((done, total, label))
        if report:
            report(done, total, label)
    result = real_run_ingest(paths, mode, action, params, speak, player,
                             guard, learn_profiles=learn_profiles)
    calls.append((mode, tuple(p.name for p in (learn_profiles or []))))
    return result


fp._run_ingest = capturing_run_ingest

# Un faux fichier à ingérer.
tmp = Path(__file__).resolve().parent / "ui_smoke_input.txt"
tmp.write_text("contenu de test", encoding="utf-8")

state = {"attempts": 0, "clicked": False}


def drive():
    state["attempts"] += 1
    if state["clicked"]:
        return
    dialogs = [w for w in app.topLevelWidgets()
               if isinstance(w, QDialog) and w.isVisible()]
    if not dialogs:
        if state["attempts"] > 40:
            print("FAIL: la fenêtre n'est jamais apparue")
            app.quit()
        return
    win = dialogs[0]

    # Clic Apprentissage → la page des agents s'ouvre, les 49 profils sont là.
    state["clicked"] = True
    win.learn_button.click()
    assert win.pages.currentIndex() == 2, "la page agents ne s'est pas ouverte"
    found = len(win._agents_checks)
    print(f"agents listés dans la fenêtre : {found}")
    assert found >= 40, f"trop peu d'agents dans la fenêtre : {found}"

    # Tout décocher, recocher un seul : le launch doit passer ce seul agent.
    win._set_agents(False)
    assert not any(cb.isChecked() for cb in win._agents_checks)
    win._agents_checks[0].setChecked(True)
    win._launch_learning()          # ferme la fenêtre quand le stub finit


QTimer(app, interval=50, timeout=drive).start()
result = fp._qt_ingestion_window([tmp], "", {}, None, None, None)
tmp.unlink()

print("window result:", result)
print("calls:", calls)
print("reports (premiers):", reports[:6])
assert len(calls) == 1 and calls[0][0] == "learn" and len(calls[0][1]) == 1, calls
assert reports and reports[-1] == (1, 1, reports[-1][2]), "total doit être int et atteindre 1/1"
assert "3 page(s)" in result, result
assert "Self-knowledge mise à jour" in result, result
self_doc = tmp_vault / "self" / "mark-liv-theology.md"
assert self_doc.exists(), "doc self-knowledge absent"
assert "AUTO-START: agents" in self_doc.read_text(encoding="utf-8")
print("UI SMOKE OK")
