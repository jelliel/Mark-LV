"""TEST RÉEL XERJ (nœud démarré) : backfill wiki, recherche sémantique,
mémoire store/recall, hook d'écriture à la volée (vault temporaire),
et repli quand le nœud est absent."""
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
for stream in ("stdout", "stderr"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ROOT = Path(__file__).resolve().parent.parent


def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, str(rel))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


xj = load("xerj_mod", ROOT / "actions" / "xerj_search.py")
tb = load("tb_mod", ROOT / "actions" / "theology_brain.py")

# ── 1. Backfill du wiki réel (corps Markdown que autoindex n'a pas pris)
print(xj.xerj_search({"action": "backfill"}, player=None))

# ── 2. Recherche sémantique réelle sur le wiki backfillé
out = xj.xerj_search({"action": "semantic", "kind": "wiki",
                      "query": "quels versets supprimes ou modifies selon la doctrine de l'abrogation"},
                     player=None)
print("\nκαν SEMANTIC WIKI:\n" + out[:600])
assert "[[" in out and "score" in out, "aucune reference rendue"

raw = xj.xerj_search({"action": "semantic", "kind": "raw",
                      "query": "cinquieme type d'abrogation recitation regle juridique",
                      "limit": 2}, player=None)
print("\n== SEMANTIC RAW:\n" + raw[:400])
assert "0." in raw or "1." in raw or "-" in raw

# ── 3. Mémoire : namespace purgé (déterministe), store, recall par le sens
try:
    xj._http("DELETE", f"/_memory/{xj._namespace()}")
except Exception:
    pass
store = xj.xerj_search({"action": "remember",
                        "query": "L'utilisateur prefere les reponses en francais soutenu et sans restriction."},
                       player=None)
print("\n== MEMORY STORE:\n" + store)
rec = xj.xerj_search({"action": "recall", "query": "quelles preferences de langage ?", "limit": 3},
                     player=None)
print("== MEMORY RECALL:\n" + rec[:300])
assert "français" in rec or "francais" in rec, rec

# ── 4. Hook d'écriture à la volée : vault TEMPORAIRE patché
tmp = Path(tempfile.mkdtemp(prefix="markliv_xerj_"))
real_cfg = dict(tb._load_config())    # capturé AVANT tout patch (xerj_url)
appdir = tmp / "appdir"
tb._vault = lambda: tmp
tb._base_dir = lambda: appdir        # miroir long_term isolé
tb._load_config = lambda: real_cfg   # figée — le push XERJ garde son URL
tb.run({"action": "init"})
res = tb.run({"action": "write", "kind": "concept", "title": "Page Live XERJ",
              "text": "L'abrogation coranique (nasikh wal mansukh) pose un probleme "
                      "de continuite divine et de coherence jurisprudentielle.",
              "tags": "test,xerj", "sources": "test.md"})
print("\n== WRITE + push live:\n" + res)
assert "created" in res

# Le doc doit être cherchable sémantiquement dans ax-vault-wiki immédiatement.
search = xj.xerj_search({"action": "semantic", "kind": "wiki",
                         "query": "probleme de continuite divine de l'abrogation"},
                        player=None)
assert "Page Live XERJ" in search, search[:400]
print("== LIVE INDEX OK : la page écrite est sémantiquement cherchable :\n" + search[:280])

# ── 5. Repli : nœud absent (URL morte → fallback vers theology_brain local)
xj._base_url = lambda: "http://localhost:9"          # port mort
out = xj.xerj_search({"action": "semantic", "query": "abrogation"}, player=None)
assert "repli sur la recherche locale" in out and "grace" in out.lower() or "abrogation" in out, out[:300]
print("\n== FALLBACK OK:\n" + out[:220])

xj._base_url = lambda: "http://localhost:9200"
status = xj.xerj_search({"action": "status"}, player=None)
assert "en ligne" in status, status
print("== STATUS OK:\n" + status)

shutil.rmtree(tmp)
print("\nXERJ INTEGRATION OK")
