# Smoke test : pipeline agents -> theology_brain, vault temporaire, Gemini simulé.
import importlib.util
import shutil
import sys
import tempfile
from pathlib import Path

for _stream in ("stdout", "stderr"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # for 'core'


import json
import tempfile


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = Path(__file__).resolve().parent.parent / "actions"   # project actions dir
ta   = load("ta_test",  base / "theology_agents.py")
fp   = load("fp_test1", base / "file_processor.py")
tb   = load("tb_test",  base / "theology_brain.py")

# Vault temporaire : on ne touche ni au vault réel ni à la config.
tmp = Path(tempfile.mkdtemp(prefix="markliv_smoke_"))
tb._vault = lambda: tmp
app_root = tmp / "appdir"          # memory/long_term.json mirror lives here
tb._base_dir = lambda: app_root

# learn_with_agents charge ses propres modules par nom fixe : on force les
# instances déjà patchées (gemini simulé + vault temporaire).
ta._load_file_processor = lambda: fp
fp._theology_brain_module = lambda: tb

# Gemini simulé : renvoie une structure fixe (une entité, un concept).
class _FakeResponse:
    def __init__(self):
        self.text = """
{
  "source": {"title": "Source Test", "tags": "test",
             "body": "Résumé de la source de test."},
  "entities": [{"title": "Augustine", "tags": "person",
                "body": "Page d'entité de test."}],
  "concepts": [{"title": "Grace", "tags": "doctrine",
                "body": "Page de concept de test."}]
}
"""

class _FakeGemini:
    def generate_content(self, prompt):
        assert "Apologete" in prompt, "le persona n'est pas dans le prompt !"
        return _FakeResponse()

fp._gemini_client = lambda: _FakeGemini()

# Un faux bureau : un mini dossier d'agents avec un profil.
agents_dir = tmp / "Agents"
agents_dir.mkdir()
(agents_dir / "agent-Apologete.md").write_text(
    "# Apologete\nUn theologien debattant catholique, specialiste de la defense "
    "de la foi et de la refutation des objections. Langue : francais.",
    encoding="utf-8")

# Fichier source de test.
src = tmp / "note.txt"
src.write_text("Augustine taught that grace precedes every good work. "
               "This is a smoke test source.", encoding="utf-8")

# Pipeline : 1 fichier x 1 agent.
profiles = ta.discover_agents(agents_dir, logger=lambda m: print(m))
assert len(profiles) == 1, profiles
result = ta.learn_with_agents([src], profiles, step=lambda d, t, l=None: print(f"  step {d}/{t} {l}"))
print("RESULT:", result)

# Vérifications dans le vault temporaire.
wiki = tmp / "wiki"
assert (wiki / "sources" / "source-test.md").exists(), "page source absente"
print("index sample:")
print((wiki / "index.md").read_text(encoding="utf-8")[:400])
page = (wiki / "entities" / "augustine.md").read_text(encoding="utf-8")
assert "Agent: Apologete" in page, page
assert "Apologete" in page, page

# ── Self-improvement : doc vivant + miroir de prompt ────
self_doc = tmp / "self" / "mark-liv-theology.md"
assert self_doc.exists(), "doc de self-knowledge absent"
sd_text = self_doc.read_text(encoding="utf-8")
for marker in ("AUTO-START: status", "AUTO-START: agents",
               "AUTO-START: contributions", "AUTO-START: recent"):
    assert marker in sd_text, marker
assert "Apologete" in sd_text, sd_text
assert "- sources: 1" in sd_text, "compte(s) absent du doc"

mirror = app_root / "memory" / "long_term.json"
assert mirror.exists(), "miroir long_term.json absent"
mdata = json.loads(mirror.read_text(encoding="utf-8"))
assert mdata["projects"]["theology"]["value"], mdata
assert "Source Test" in mdata["projects"]["theology"]["value"], mdata
print("self-knowledge doc + miroir de prompt OK")

shutil.rmtree(tmp)
